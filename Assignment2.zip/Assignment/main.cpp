
#include <unsortedtype.h>



int main()
{
    UnsortedList list1;
    list1.InsertItem(1);
    list1.InsertItem(5);
    list1.InsertItem(6);
    list1.InsertItem(10);
    list1.InsertItem(14);
    list1.InsertItem(20);
    list1.InsertItem(25);
    list1.InsertItem(31);
    list1.InsertItem(38);
    list1.InsertItem(40);

    UnsortedList list2;
    list2.InsertItem(2);
    list2.InsertItem(4);
    list2.InsertItem(7);
    list2.InsertItem(9);
    list2.InsertItem(16);
    list2.InsertItem(19);
    list2.InsertItem(23);
    list2.InsertItem(24);
    list2.InsertItem(32);
    list2.InsertItem(35);
    list2.InsertItem(36);
    list2.InsertItem(42);

    NodeType* mergedList = mergeLists(list1.head, list2.head);

    // print the merged list
    while (mergedList)
    {
        cout << mergedList->val << " ";
        mergedList = mergedList->next;
    }
    cout << endl;

    return 0;
}
