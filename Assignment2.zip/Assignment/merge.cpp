#include<unsortedtype.h>
using namespace std;

NodeType* mergeLists(NodeType* l1, NodeType* l2)
{
    if (!l1)
        return l2;
    if (!l2)
        return l1;

    NodeType* mergedHead = NULL;
    NodeType* mergedTail = NULL;

    while (l1 && l2)
    {
        if (l1->val <= l2->val)
        {
            if (!mergedHead)
            {
                mergedHead = l1;
                mergedTail = l1;
            }
            else
            {
                mergedTail->next = l1;
                mergedTail = mergedTail->next;
            }
            l1 = l1->next;
        }
        else
        {
            if (!mergedHead)
            {
                mergedHead = l2;
                mergedTail = l2;
            }
            else
            {
                mergedTail->next = l2;
                mergedTail = mergedTail->next;
            }
            l2 = l2->next;
        }
    }

    if (l1)
        mergedTail->next = l1;
    if (l2)
        mergedTail->next = l2;

    return mergedHead;
}